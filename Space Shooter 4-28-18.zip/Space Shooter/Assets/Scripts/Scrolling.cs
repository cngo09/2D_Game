﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scrolling : MonoBehaviour {

    //(0,-15,0) final pos
    //(0,20,0) reset pos
    Vector3 finalPostion = new Vector3(0, -15, 0);
    Vector3 resetPostion = new Vector3(0, 20, 0);

    void Update () {
        if (transform.position == finalPostion)
        {
            transform.position = resetPostion;
        }
        else
            transform.position = Vector3.MoveTowards(transform.position, finalPostion , 1 * Time.deltaTime);
    }
}
