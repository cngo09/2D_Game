﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarScript : MonoBehaviour
{

    public float speed;
    public Transform player;


    void FixedUpdate()
    {
        //
    }
}
