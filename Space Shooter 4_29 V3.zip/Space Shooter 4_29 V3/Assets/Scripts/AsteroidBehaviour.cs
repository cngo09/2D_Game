﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidBehaviour : MonoBehaviour {

    public GameObject Asteroid;

    private void OnTriggerEnter2D(Collider2D other)
    {
        HealthBarScript.health -= 10f;

            Destroy(Asteroid);
    }

}
