﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawning : MonoBehaviour
{ 
    public float spawnTime = 5f;        // The amount of time between each spawn.
    public float spawnDelay = 3f;       // The amount of time before spawning starts.
    public GameObject Asteroid;
    public float spawnRangeLittle = -10f;
    public float spawnRangeBig = 10f;
    float nextSpawn = 0;


    void Start()
    {
        InvokeRepeating("Spawn", spawnDelay, spawnTime);
    }

    private void Update()
    {
        if (Time.time > spawnDelay)
        {
            Spawn();
        }
    }

    void Spawn()
    {
        if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + spawnTime;
            float spawnPos = Random.Range(spawnRangeLittle, spawnRangeBig);

            var spawnPoint = new Vector3(spawnPos, transform.position.y);
            Instantiate(Asteroid, spawnPoint, Quaternion.identity);
        }
    }
}
