﻿using UnityEngine;

public class CarScript : MonoBehaviour {
    public float speed = 5f;
    public float playerSpeed;
    public Transform target;
    public float carSpeed = 5f;

    private void Update() {
        Vector3 position = new Vector3(0,0,0);
        Vector3 targetPos = target.position;
        Vector3 home = new Vector3(targetPos.x, targetPos.y - 3, targetPos.z);


        Vector2 direction = target.position - transform.position;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        Quaternion rotation = Quaternion.AngleAxis(angle - 90, Vector3.forward);
        transform.rotation = Quaternion.Slerp(transform.rotation, rotation, speed * Time.deltaTime);


        
        transform.position = Vector3.MoveTowards(transform.position, home, carSpeed * Time.deltaTime);
        transform.position = new Vector3(transform.position.x, home.y, transform.position.z);
    }
}
