﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidMovement : MonoBehaviour {

    
    
    //public Transform target;
    public float speed;
    public Transform target;  
    
    void Update()
    {
        transform.position += Vector3.down * Time.deltaTime * speed;
    }
}
