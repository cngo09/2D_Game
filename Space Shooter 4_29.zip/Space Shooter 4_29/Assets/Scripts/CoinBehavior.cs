﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinBehavior : MonoBehaviour {

	public GameObject Coin;

	private void OnTriggerEnter2D(Collider2D other)
	{
		//Call Score Script
		ScoreScript.scoreValue += 1;
		Destroy(Coin);
	}
}
