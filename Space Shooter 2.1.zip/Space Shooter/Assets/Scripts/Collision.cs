﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Collision : MonoBehaviour
{
    public string level;
    

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Car")
        {
            SceneManager.LoadScene(level, LoadSceneMode.Single);
        }
    }
}
