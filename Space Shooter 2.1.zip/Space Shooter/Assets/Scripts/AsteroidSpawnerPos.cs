﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidSpawnerPos : MonoBehaviour {

    public GameObject Asteroid;
    float randomX;
    Vector2 location;
    public float spawnRate = 2f;
    float nextSpawn = 0.0f;
	
	// Update is called once per frame
	void Update () {
		
        if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + spawnRate;
            randomX = Random.Range(0f, 10.1f);
            location = new Vector2(randomX, transform.position.y);
            Instantiate(Asteroid, location, Quaternion.identity);
        }
	}
}
