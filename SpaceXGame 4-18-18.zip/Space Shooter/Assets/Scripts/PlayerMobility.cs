﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// PlayerScript requires the GameObject to have a Rigidbody2D component

[RequireComponent(typeof(Rigidbody2D))]

public class PlayerMobility : MonoBehaviour
{
    public float playerSpeed;


    void FixedUpdate()
    {

        transform.Translate((transform.up * Input.GetAxisRaw("Vertical") + transform.right * Input.GetAxisRaw("Horizontal")) * playerSpeed * Time.deltaTime);
    }
}
