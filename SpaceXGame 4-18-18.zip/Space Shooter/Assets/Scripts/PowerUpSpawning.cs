﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUpSpawning : MonoBehaviour
{
    public float spawnTime = 5f;        // The amount of time between each spawn.
    public float spawnDelay = 3f;       // The amount of time before spawning starts.
    public GameObject PowerUp1;
    float nextSpawn = 0;

    // Use this for initialization
    void Start()
    {
        // Start calling the Spawn function repeatedly after a delay .
        InvokeRepeating("Spawn", spawnDelay, spawnTime);
    }

    private void Update()
    {
        if (Time.time > spawnDelay)
        {
            Spawn();
        }
    }

    void Spawn()
    {
        // Have the evil swans spawn in a random Y position (range is about 2 to 7.5 ( Hint Random.Range)
        // If you are completely stuck scroll down for the code.
        if (Time.time > nextSpawn) {
            nextSpawn = Time.time + spawnTime;
            float spawnPos = Random.Range(-10f, 10f);

            var spawnPoint = new Vector3(spawnPos, transform.position.y);
            Instantiate(PowerUp1, spawnPoint, Quaternion.identity);
        }
    }
}
