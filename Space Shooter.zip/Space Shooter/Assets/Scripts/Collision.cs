﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Collision : MonoBehaviour
{
    public string level;
    private AudioSource source;

    private void Start()
    {
        source = GetComponent<AudioSource>();
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Car")
        {
            source.Play();
            SceneManager.LoadScene(level, LoadSceneMode.Single);
        }
    }
}
