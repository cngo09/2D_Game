﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarScript : MonoBehaviour {

    public float speed;
    public Transform player;
    

    void FixedUpdate()
    {
       // float z = Mathf.Atan2((player.transform.position.y - transform.position.y), (player.transform.position.x - transform.position.x))* Mathf.Rad2Deg - 90;

        transform.position = new Vector3((player.transform.position.x), (player.transform.position.y - 3), 0);

        GetComponent<Rigidbody2D>().AddForce(gameObject.transform.up * speed);
        
    }
}
