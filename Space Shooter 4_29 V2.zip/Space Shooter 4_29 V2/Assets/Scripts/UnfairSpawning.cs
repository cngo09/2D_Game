﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnfairSpawning : MonoBehaviour {
    public float spawnTime = 5f;        // The amount of time between each spawn.
    public float spawnDelay = 3f;       // The amount of time before spawning starts.
    public GameObject Asteroid;
    public GameObject Player;
    float nextSpawn = 0;

    // Use this for initialization
    void Start()
    {
        // Start calling the Spawn function repeatedly after a delay .
        InvokeRepeating("Spawn", spawnDelay, spawnTime);
    }

    private void Update()
    {
        if (Time.time > spawnDelay)
        {
            Spawn();
        }
    }

    void Spawn()
    {
        // Have the evil swans spawn in a random Y position (range is about 2 to 7.5 ( Hint Random.Range)
        // If you are completely stuck scroll down for the code.
        if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + spawnTime;
            float spawnPos = Random.Range(-10f, 10f);

            var unfairSpawn = new Vector3(Player.transform.position.x, transform.position.y);
            Instantiate(Asteroid, unfairSpawn, Quaternion.identity);
        }
    }
}
