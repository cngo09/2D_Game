﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinSpawning : MonoBehaviour
{
    public float spawnTime = 5f;        // The amount of time between each spawn.
    public float spawnDelay = 3f;       // The amount of time before spawning starts.
    public GameObject Coin;
    float nextSpawn = 0;


    void Start()
    {
        InvokeRepeating("Spawn", spawnDelay, spawnTime);
    }

    private void Update()
    {
        if (Time.time > spawnDelay)
        {
            Spawn();
        }
    }

    void Spawn()
    {
        if (Time.time > nextSpawn)
        {
            nextSpawn = Time.time + 3 * spawnTime;
            float spawnPos = Random.Range(-10f, 10f);

            for (int i = 0; i < 8; i++)
            {
                var spawnPoint = new Vector3(spawnPos, transform.position.y + i);
                Instantiate(Coin, spawnPoint, Quaternion.identity);
            }
            
        }
    }
}
