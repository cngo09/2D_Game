﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveScript : MonoBehaviour {

	public Vector2 speed = new Vector2 (100, 100);

	public Vector2 direction = new Vector2 (0, 1);

	// Update is called once per frame
	void Update () {
		Vector3 movement = new Vector3 (speed.y * direction.y, speed.x * direction.x, 0);

		movement *= Time.deltaTime;

		transform.Translate (movement);
		
	}
}
