﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserScript : MonoBehaviour {

	public int damage = 1;
	public bool isAsteroidShot = false;

	// Use this for initialization
	void Start () {
		Destroy (gameObject, 20);
		
	}
}
