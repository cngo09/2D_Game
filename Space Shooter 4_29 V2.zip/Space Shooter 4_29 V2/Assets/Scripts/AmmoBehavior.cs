﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AmmoBehavior : MonoBehaviour {

	public GameObject Ammo;

	private void OnTriggerEnter2D(Collider2D other)
	{
		//Call shooting script
		Destroy(Ammo);
	}
}