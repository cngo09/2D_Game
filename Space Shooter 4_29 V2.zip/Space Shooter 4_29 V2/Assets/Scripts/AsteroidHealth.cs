﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidHealth : MonoBehaviour {

	public int hp = 1;

	public bool isEnemy = true;

	void OnTriggerEnter2D (Collider2D  collider) {

		LaserScript shot = collider.gameObject.GetComponent<LaserScript> ();

		if (shot != null) {
			if (shot.isAsteroidShot != isEnemy) {
				hp -= shot.damage;

				Destroy (shot.gameObject);

				if (hp <= 0) {
					Destroy (gameObject);
				}
			}
		}
	}
}
